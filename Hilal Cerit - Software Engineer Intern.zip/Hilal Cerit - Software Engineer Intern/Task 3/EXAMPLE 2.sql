INSERT INTO public.test_groups(
	name, test_value)
	VALUES ('partial functionality', 20),
	('full functionality', 40);
	
INSERT INTO public.test_cases(
	id, group_name, status)
	VALUES (1,'performance', 'ERROR'),(2,'full functionality','ERROR');

DELETE FROM public.test_cases
	WHERE id BETWEEN 13 and 21; 

SELECT TG."name" as "name" , COUNT(group_name) as all_test_cases , 
SUM( CASE WHEN status = 'OK' THEN 1 ELSE 0 END ) as passed_test_cases ,
 SUM (CASE WHEN status = 'OK' THEN test_value ELSE 0 END) as total_value
FROM test_cases AS TC FULL OUTER JOIN test_groups AS TG ON TC.group_name=TG."name"
GROUP BY TG."name"
ORDER BY TG."name";