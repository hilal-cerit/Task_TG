INSERT INTO public.test_groups(
	name, test_value)
	VALUES ('performance', 15),
	('corner cases', 10),
	('numerical stability', 20),
	 ('memory usage', 10);

INSERT INTO public.test_cases(
	id, group_name, status)
	VALUES (13,'memory usage', 'OK'),(14,'numerical stability','OK'),
	(15,'memory usage', 'ERROR'),(16,'numerical stability','OK'),
	(17,'numerical stability','OK'),(18,'performance','ERROR'),
	(19,'performance','ERROR'),(20,'memory usage', 'OK'),(21,'numerical stability','OK');

SELECT TG."name" as "name" , COUNT(group_name) as all_test_cases , 
SUM( CASE WHEN status = 'OK' THEN 1 ELSE 0 END ) as passed_test_cases ,
 SUM (CASE WHEN status = 'OK' THEN test_value ELSE 0 END) as total_value
FROM test_cases AS TC FULL OUTER JOIN test_groups AS TG ON TC.group_name=TG."name"
GROUP BY TG."name"
ORDER BY total_value DESC;